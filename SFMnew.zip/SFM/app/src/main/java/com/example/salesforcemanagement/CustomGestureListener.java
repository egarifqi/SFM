package com.example.salesforcemanagement;

import android.gesture.Gesture;
import android.gesture.GestureOverlayView;
import android.gesture.GestureOverlayView.OnGesturePerformedListener;

/**
 * Created by Administrator on 5/3/2018.
 */

public class CustomGestureListener implements OnGesturePerformedListener {


    @Override
    public void onGesturePerformed(GestureOverlayView gestureOverlayView, Gesture gesture) {

    }
}