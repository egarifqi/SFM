package com.example.salesforcemanagement;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class DatabaseNPDPromoHandler extends SQLiteOpenHelper {
    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "produkNPDManager";
    private static final String TABLE_PRODUK_NPD = "produkNPD";
    private static final String KEY_ID = "id";
    private static final String KEY_CODE = "kode";
    private static final String KEY_NAME = "name";
    private static final String KEY_PRICE = "price";
    private static final String KEY_STOCK = "stock";
    private static final String KEY_QTY = "qty";
    private static final String KEY_CATEGORY = "category";
    private static final String KEY_PRODUCT_TYPE = "p_type";
    private static final String KEY_BARCODE = "barcode";
    private static final String KEY_WEEKLY_SALES = "w_sales";
    private static final String KEY_BRAND = "brand";
    private static final String KEY_PARTNER_ID = "partner_id";
    private static final String KEY_PCS = "pcs";
    ContentValues values = new ContentValues();

    public DatabaseNPDPromoHandler(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        //3rd argument to be passed is CursorFactory instance
    }

    // Creating Tables
    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_CONTACTS_TABLE = "CREATE TABLE " + TABLE_PRODUK_NPD + "("
                + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + KEY_CODE + " TEXT,"
                + KEY_NAME + " TEXT,"
                + KEY_PRICE + " TEXT,"
                + KEY_CATEGORY +" TEXT,"
                + KEY_PRODUCT_TYPE +" TEXT,"
                + KEY_BARCODE + " TEXT,"
                + KEY_WEEKLY_SALES+" INTEGER,"
                + KEY_PARTNER_ID +" TEXT,"
                + KEY_BRAND + " TEXT,"
                + KEY_STOCK +" TEXT,"
                + KEY_QTY + " TEXT,"
                + KEY_PCS + " TEXT"
                + ")";
        db.execSQL(CREATE_CONTACTS_TABLE);
    }

    // Upgrading database
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop older table if existed
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_PRODUK_NPD);

        // Create tables again
        onCreate(db);
    }

    // code to add the new contact
    void addProduk( Spacecraft s) {
        SQLiteDatabase db = this.getWritableDatabase();

//        ContentValues values = new ContentValues();

        values.put(KEY_CODE, s.getKodeodoo());
        values.put(KEY_NAME, s.getNamaproduk());
        values.put(KEY_PRICE, s.getPrice());
        values.put(KEY_STOCK, s.getStock());
        values.put(KEY_QTY, s.getQty());
        values.put(KEY_CATEGORY, s.getCategory());
        values.put(KEY_PRODUCT_TYPE, s.getProducttype());
        values.put(KEY_BARCODE, s.getBarcode());
        values.put(KEY_WEEKLY_SALES, s.getWeeklySales());
        values.put(KEY_PARTNER_ID, s.getPartner_id());
        values.put(KEY_BRAND, s.getBrand());
        values.put(KEY_PCS, s.getKoli());

        // Inserting Row
        db.insert(TABLE_PRODUK_NPD, null, values);
        //2nd argument is String containing nullColumnHack
        db.close(); // Closing database connection
    }

    void addAllProduk(JSONArray ja, int length) throws JSONException {
        SQLiteDatabase db = this.getWritableDatabase();
        Spacecraft s = new Spacecraft();
        db.beginTransaction();
        JSONObject jo;
//        Log.e("JSON", ja.toString());

        try {
            for (int i = 0; i < length; i++) {
                jo = ja.getJSONObject(i);
//            Log.e("EBP_"+i, jo.toString());
//        ContentValues values = new ContentValues();
                values.put(KEY_CODE, jo.getString("default_code"));
                values.put(KEY_NAME, jo.getString("name"));
                values.put(KEY_PRICE, jo.getString("price"));
                values.put(KEY_STOCK, jo.getString("stock_qty"));
                values.put(KEY_QTY, "0");
                values.put(KEY_CATEGORY, jo.getString("category"));
                values.put(KEY_PRODUCT_TYPE, jo.getString("product_type"));
                values.put(KEY_BARCODE, jo.getString("barcode"));
                values.put(KEY_WEEKLY_SALES, jo.getInt("weekly_qty"));
                values.put(KEY_PARTNER_ID, jo.getString("partner_id"));
                values.put(KEY_BRAND, jo.getString("brand"));
                values.put(KEY_PCS, jo.getString("unit"));

                // Inserting Row
                db.insert(TABLE_PRODUK_NPD, null, values);
//                Log.e("EBP_" + i, values.toString());
            }
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
//        db.setTransactionSuccessful();
//        db.endTransaction();
        //2nd argument is String containing nullColumnHack
//        Log.e("DATABASE", db.toString());
        db.close(); // Closing database connection
    }



    // code to get the single contact
    Spacecraft getProduk(int id) {
        SQLiteDatabase db = this.getReadableDatabase();
        Spacecraft s = new Spacecraft();

        Cursor cursor = db.query(TABLE_PRODUK_NPD, new String[] { KEY_ID, KEY_CODE, KEY_NAME, KEY_PRICE,
                        KEY_CATEGORY, KEY_PRODUCT_TYPE, KEY_BARCODE, KEY_WEEKLY_SALES,
                        KEY_PARTNER_ID, KEY_BRAND, KEY_STOCK, KEY_QTY}, KEY_ID + "=?",
                new String[] { String.valueOf(id) }, null, null, null, null);
        if (cursor != null)
            cursor.moveToFirst();
        if (cursor != null && cursor.moveToFirst()) {
            s = new Spacecraft(Integer.parseInt(cursor.getString(0)),
                    cursor.getString(1), cursor.getString(2),
                    cursor.getString(3), cursor.getString(4),
                    cursor.getString(5), cursor.getString(6),
                    cursor.getInt(7), cursor.getString(8),
                    cursor.getString(9), cursor.getString(10),
                    cursor.getString(11), cursor.getString(12));
            cursor.close();
        }
        // return contact
        return s;
    }

    Spacecraft getProdukToko(int id, String partnerid, String brand) {
        SQLiteDatabase db = this.getReadableDatabase();
        Spacecraft s = new Spacecraft();

        Cursor cursor = db.query(TABLE_PRODUK_NPD, new String[] { KEY_ID, KEY_CODE, KEY_NAME, KEY_PRICE,
                KEY_CATEGORY, KEY_BARCODE, KEY_WEEKLY_SALES, KEY_PARTNER_ID, KEY_BRAND, KEY_STOCK,
                KEY_QTY, KEY_PCS}, KEY_ID + "=? AND " + KEY_PARTNER_ID + "=? AND " + KEY_BRAND + "=?", new String[]
                { String.valueOf(id), partnerid, brand }, null, null, null, null);
        if (cursor != null)
            cursor.moveToFirst();
        if (cursor != null && cursor.moveToFirst()) {
            s = new Spacecraft(Integer.parseInt(cursor.getString(0)),
                    cursor.getString(1), cursor.getString(2),
                    cursor.getString(3), cursor.getString(4),
                    "", cursor.getString(5),
                    cursor.getInt(6), cursor.getString(7),
                    cursor.getString(8), cursor.getString(9),
                    cursor.getString(10), cursor.getString(11));
            cursor.close();
        }
        // return contact
        return s;
    }


    // code to get all contacts in a list view
    public ArrayList< Spacecraft> getAllProduk() {
        ArrayList< Spacecraft> listProduk = new ArrayList< Spacecraft>();
        Spacecraft contact = new Spacecraft();
        // Select All Query
        String selectQuery = "SELECT * FROM " + TABLE_PRODUK_NPD;

        SQLiteDatabase db = this.getReadableDatabase();
        try {
            Cursor cursor = db.rawQuery(selectQuery, null);
            try {
                // looping through all rows and adding to list
                if (cursor.moveToFirst()) {
                    do {
//                Spacecraft contact = new Spacecraft();
                        contact.setId(Integer.parseInt(cursor.getString(0)));
                        contact.setKodeodoo(cursor.getString(1));
                        contact.setNamaproduk(cursor.getString(2));
                        contact.setPrice(cursor.getString(3));
                        contact.setCategory(cursor.getString(4));
                        contact.setProducttype(cursor.getString(5));
                        contact.setBarcode(cursor.getString(6));
                        contact.setWeeklySales(cursor.getInt(7));
                        contact.setPartner_id(cursor.getString(8));
                        contact.setBrand(cursor.getString(9));
                        contact.setStock(cursor.getString(10));
                        contact.setQty(cursor.getString(11));
                        contact.setKoli(cursor.getString(12));

                        // Adding contact to list
                        listProduk.add(contact);
//                        cursor.moveToNext();
                    } while (cursor.moveToNext());
                }
            } finally {
                try {
                    cursor.close();
                } catch (Exception e) {
                    Log.e("Error 1", e.getMessage());
                }
            }
        } finally {
            try {
                db.close();
            } catch (Exception e){
                Log.e("Error 2", e.getMessage());
            }
        }

        // return contact list
        return listProduk;
    }

    public ArrayList< Spacecraft> getAllProdukToko(String partnerid, String brand) {
        ArrayList< Spacecraft> listProduk = new ArrayList< Spacecraft>();
//        Spacecraft contact = new Spacecraft();
        // Select All Query
        String selectQuery = "SELECT * FROM " + TABLE_PRODUK_NPD + " WHERE " + KEY_PARTNER_ID + " IS " + partnerid + " AND " + KEY_BRAND + " IS '" + brand + "'";

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                Spacecraft contact = new Spacecraft();
                contact.setId(Integer.parseInt(cursor.getString(cursor.getColumnIndex(KEY_ID))));
                contact.setKodeodoo(cursor.getString(cursor.getColumnIndex(KEY_CODE)));
                contact.setNamaproduk(cursor.getString(cursor.getColumnIndex(KEY_NAME)));
                contact.setPrice(cursor.getString(cursor.getColumnIndex(KEY_PRICE)));
                contact.setCategory(cursor.getString(cursor.getColumnIndex(KEY_CATEGORY)));
                contact.setBarcode(cursor.getString(cursor.getColumnIndex(KEY_BARCODE)));
                contact.setWeeklySales(cursor.getInt(cursor.getColumnIndex(KEY_WEEKLY_SALES)));
                contact.setPartner_id(cursor.getString(cursor.getColumnIndex(KEY_PARTNER_ID)));
                contact.setBrand(cursor.getString(cursor.getColumnIndex(KEY_BRAND)));
                contact.setStock(cursor.getString(cursor.getColumnIndex(KEY_STOCK)));
                contact.setQty(cursor.getString(cursor.getColumnIndex(KEY_QTY)));
                contact.setProducttype(cursor.getString(cursor.getColumnIndex(KEY_PRODUCT_TYPE)));
                contact.setKoli(cursor.getString(cursor.getColumnIndex(KEY_PCS)));

                // Adding contact to list
                listProduk.add(contact);
            } while (cursor.moveToNext());
        }
        cursor.close();

        // return contact list
        return listProduk;
    }

    // code to update the single contact
    public int updateProduk( Spacecraft s) {
        SQLiteDatabase db = this.getWritableDatabase();

//        ContentValues values = new ContentValues();
        values.put(KEY_CODE, s.getKodeodoo());
        values.put(KEY_NAME, s.getNamaproduk());
        values.put(KEY_PRICE, s.getPrice());
        values.put(KEY_STOCK, s.getStock());
        values.put(KEY_QTY, s.getQty());
        values.put(KEY_CATEGORY, s.getCategory());
        values.put(KEY_PRODUCT_TYPE, s.getProducttype());
        values.put(KEY_BARCODE, s.getBarcode());
        values.put(KEY_WEEKLY_SALES, s.getWeeklySales());
        values.put(KEY_PARTNER_ID, s.getPartner_id());
        values.put(KEY_BRAND, s.getBrand());
        values.put(KEY_PCS, s.getKoli());

        // updating row
        return db.update(TABLE_PRODUK_NPD, values, KEY_ID + " = ?",
                new String[] { String.valueOf(s.getId()) });
    }

    // Deleting single contact
    public void deleteProduk( Spacecraft contact) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_PRODUK_NPD, KEY_ID + " = ?",
                new String[] { String.valueOf(contact.getId()) });
        db.close();
    }

    public void deleteAll(){
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "DELETE FROM " + TABLE_PRODUK_NPD;
        db.execSQL(query);
        db.close();
    }

    // Getting contacts Count
    public int getProductCount() {
        String countQuery = "SELECT  * FROM " + TABLE_PRODUK_NPD;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(countQuery, null);
//        cursor.close();

        // return count
        return cursor.getCount();
    }

}

