package com.example.salesforcemanagement;

import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.salesforcemanagement.R;

public class TokoBaruFragment extends Fragment {

    public View onCreateView(final LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        final View view = inflater.inflate(R.layout.fragment_toko_baru, container, false);

        return view;
    }
}
