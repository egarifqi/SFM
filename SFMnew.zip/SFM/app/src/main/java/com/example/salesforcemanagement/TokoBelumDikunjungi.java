package com.example.salesforcemanagement;

import java.util.ArrayList;

public class TokoBelumDikunjungi {
    public static ArrayList<Integer> idtoko = new ArrayList<Integer>();
    public static ArrayList<String> kodetoko = new ArrayList<String>();
    public static ArrayList<String> namatoko = new ArrayList<String>();
    public static ArrayList<String> salesidtoko = new ArrayList<String>();
    public static ArrayList<String> partneridtoko = new ArrayList<String>();

    public static void clearBelumDikunjungi(){
        idtoko.clear();
        kodetoko.clear();
        namatoko.clear();
        salesidtoko.clear();
        partneridtoko.clear();
    }
}
