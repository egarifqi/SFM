package com.example.salesforcemanagement;

import org.junit.Test;

public class MainActivityTest {

    @Test
    public void onCreate() {
    }
}